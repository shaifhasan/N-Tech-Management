﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nTech.presentation_layer.employee_presentation
{
    public partial class employeeHome : Form
    {
        public employeeHome()
        {
            InitializeComponent();
        }

        private void employeeHome_Load(object sender, EventArgs e)
        {

        }
    }
}
