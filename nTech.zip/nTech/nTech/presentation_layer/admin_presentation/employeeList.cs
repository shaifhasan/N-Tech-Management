﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nTech.business_logic_layer.admin;

namespace nTech.presentation_layer.admin_presentation
{
    public partial class employeeList : Form
    {
        EmployeeLogic emp = new EmployeeLogic();
        public employeeList()
        {
            InitializeComponent();
        }

        private void employeeList_Load(object sender, EventArgs e)
        {
            DataTable empList = emp.getEmpList();
            listView.DataSource = empList;
          
        }
    }
}
