﻿namespace nTech.presentation_layer.admin_presentation
{
    partial class addEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addEmployee));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.Egender = new Bunifu.UI.WinForms.BunifuDropdown();
            this.Ename = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Eage = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Ephone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Eaddress = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Esalary = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Eid = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.Epass = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(417, 94);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(175, 160);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.ButtonText = "Add";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton1.IdleBorderRadius = 1;
            this.bunifuButton1.IdleBorderThickness = 0;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.Location = new System.Drawing.Point(396, 381);
            this.bunifuButton1.Name = "bunifuButton1";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.BorderRadius = 1;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.bunifuButton1.onHoverState = stateProperties1;
            this.bunifuButton1.Size = new System.Drawing.Size(210, 45);
            this.bunifuButton1.TabIndex = 2;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // Egender
            // 
            this.Egender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Egender.BackColor = System.Drawing.SystemColors.Control;
            this.Egender.BorderRadius = 1;
            this.Egender.Color = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Egender.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.Egender.DisabledColor = System.Drawing.Color.Gray;
            this.Egender.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Egender.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thick;
            this.Egender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Egender.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.Egender.FillDropDown = false;
            this.Egender.FillIndicator = false;
            this.Egender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Egender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Egender.FormattingEnabled = true;
            this.Egender.Icon = null;
            this.Egender.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Egender.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.Egender.ItemBackColor = System.Drawing.Color.White;
            this.Egender.ItemBorderColor = System.Drawing.Color.White;
            this.Egender.ItemForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Egender.ItemHeight = 26;
            this.Egender.ItemHighLightColor = System.Drawing.Color.Thistle;
            this.Egender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.Egender.Location = new System.Drawing.Point(5, 377);
            this.Egender.Name = "Egender";
            this.Egender.Size = new System.Drawing.Size(379, 32);
            this.Egender.TabIndex = 4;
            this.Egender.Text = "Select Gender";
            // 
            // Ename
            // 
            this.Ename.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Ename.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Ename.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Ename.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Ename.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Ename.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Ename.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Ename.HintForeColor = System.Drawing.Color.Empty;
            this.Ename.HintText = "";
            this.Ename.isPassword = false;
            this.Ename.LineFocusedColor = System.Drawing.Color.Blue;
            this.Ename.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Ename.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Ename.LineThickness = 3;
            this.Ename.Location = new System.Drawing.Point(5, 13);
            this.Ename.Margin = new System.Windows.Forms.Padding(4);
            this.Ename.MaxLength = 32767;
            this.Ename.Name = "Ename";
            this.Ename.Size = new System.Drawing.Size(379, 32);
            this.Ename.TabIndex = 5;
            this.Ename.Text = "Name";
            this.Ename.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Ename.Click += new System.EventHandler(this.E_click);
            // 
            // Eage
            // 
            this.Eage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Eage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Eage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Eage.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Eage.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Eage.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Eage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Eage.HintForeColor = System.Drawing.Color.Empty;
            this.Eage.HintText = "";
            this.Eage.isPassword = false;
            this.Eage.LineFocusedColor = System.Drawing.Color.Blue;
            this.Eage.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Eage.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Eage.LineThickness = 3;
            this.Eage.Location = new System.Drawing.Point(5, 65);
            this.Eage.Margin = new System.Windows.Forms.Padding(4);
            this.Eage.MaxLength = 32767;
            this.Eage.Name = "Eage";
            this.Eage.Size = new System.Drawing.Size(379, 32);
            this.Eage.TabIndex = 5;
            this.Eage.Text = "Age";
            this.Eage.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Eage.Click += new System.EventHandler(this.E_click);
            // 
            // Ephone
            // 
            this.Ephone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Ephone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Ephone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Ephone.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Ephone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Ephone.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Ephone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Ephone.HintForeColor = System.Drawing.Color.Empty;
            this.Ephone.HintText = "";
            this.Ephone.isPassword = false;
            this.Ephone.LineFocusedColor = System.Drawing.Color.Blue;
            this.Ephone.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Ephone.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Ephone.LineThickness = 3;
            this.Ephone.Location = new System.Drawing.Point(5, 117);
            this.Ephone.Margin = new System.Windows.Forms.Padding(4);
            this.Ephone.MaxLength = 32767;
            this.Ephone.Name = "Ephone";
            this.Ephone.Size = new System.Drawing.Size(379, 32);
            this.Ephone.TabIndex = 5;
            this.Ephone.Text = "Phone";
            this.Ephone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Ephone.Click += new System.EventHandler(this.E_click);
            // 
            // Eaddress
            // 
            this.Eaddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Eaddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Eaddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Eaddress.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Eaddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Eaddress.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Eaddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Eaddress.HintForeColor = System.Drawing.Color.Empty;
            this.Eaddress.HintText = "";
            this.Eaddress.isPassword = false;
            this.Eaddress.LineFocusedColor = System.Drawing.Color.Blue;
            this.Eaddress.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Eaddress.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Eaddress.LineThickness = 3;
            this.Eaddress.Location = new System.Drawing.Point(5, 169);
            this.Eaddress.Margin = new System.Windows.Forms.Padding(4);
            this.Eaddress.MaxLength = 32767;
            this.Eaddress.Name = "Eaddress";
            this.Eaddress.Size = new System.Drawing.Size(379, 32);
            this.Eaddress.TabIndex = 5;
            this.Eaddress.Text = "Address";
            this.Eaddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Eaddress.Click += new System.EventHandler(this.E_click);
            // 
            // Esalary
            // 
            this.Esalary.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Esalary.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Esalary.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Esalary.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Esalary.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Esalary.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Esalary.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Esalary.HintForeColor = System.Drawing.Color.Empty;
            this.Esalary.HintText = "";
            this.Esalary.isPassword = false;
            this.Esalary.LineFocusedColor = System.Drawing.Color.Blue;
            this.Esalary.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Esalary.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Esalary.LineThickness = 3;
            this.Esalary.Location = new System.Drawing.Point(5, 221);
            this.Esalary.Margin = new System.Windows.Forms.Padding(4);
            this.Esalary.MaxLength = 32767;
            this.Esalary.Name = "Esalary";
            this.Esalary.Size = new System.Drawing.Size(379, 32);
            this.Esalary.TabIndex = 5;
            this.Esalary.Text = "Salary";
            this.Esalary.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Esalary.Click += new System.EventHandler(this.E_click);
            // 
            // Eid
            // 
            this.Eid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Eid.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Eid.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Eid.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Eid.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Eid.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Eid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Eid.HintForeColor = System.Drawing.Color.Empty;
            this.Eid.HintText = "";
            this.Eid.isPassword = false;
            this.Eid.LineFocusedColor = System.Drawing.Color.Blue;
            this.Eid.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Eid.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Eid.LineThickness = 3;
            this.Eid.Location = new System.Drawing.Point(5, 273);
            this.Eid.Margin = new System.Windows.Forms.Padding(4);
            this.Eid.MaxLength = 32767;
            this.Eid.Name = "Eid";
            this.Eid.Size = new System.Drawing.Size(379, 32);
            this.Eid.TabIndex = 5;
            this.Eid.Text = "Id Number";
            this.Eid.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Eid.Click += new System.EventHandler(this.E_click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(428, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 31);
            this.label1.TabIndex = 6;
            this.label1.Text = "Employees";
            // 
            // Epass
            // 
            this.Epass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Epass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Epass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Epass.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Epass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Epass.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Epass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Epass.HintForeColor = System.Drawing.Color.Empty;
            this.Epass.HintText = "";
            this.Epass.isPassword = false;
            this.Epass.LineFocusedColor = System.Drawing.Color.Blue;
            this.Epass.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Epass.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Epass.LineThickness = 3;
            this.Epass.Location = new System.Drawing.Point(5, 325);
            this.Epass.Margin = new System.Windows.Forms.Padding(4);
            this.Epass.MaxLength = 32767;
            this.Epass.Name = "Epass";
            this.Epass.Size = new System.Drawing.Size(379, 32);
            this.Epass.TabIndex = 5;
            this.Epass.Text = "Password";
            this.Epass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Epass.Click += new System.EventHandler(this.E_click);
            // 
            // addEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 447);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Epass);
            this.Controls.Add(this.Eid);
            this.Controls.Add(this.Esalary);
            this.Controls.Add(this.Eaddress);
            this.Controls.Add(this.Ephone);
            this.Controls.Add(this.Eage);
            this.Controls.Add(this.Ename);
            this.Controls.Add(this.Egender);
            this.Controls.Add(this.bunifuButton1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "addEmployee";
            this.Text = "addEmployee";
            this.Load += new System.EventHandler(this.addEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private Bunifu.UI.WinForms.BunifuDropdown Egender;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Ename;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Eage;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Ephone;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Eaddress;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Esalary;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Eid;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Epass;
    }
}