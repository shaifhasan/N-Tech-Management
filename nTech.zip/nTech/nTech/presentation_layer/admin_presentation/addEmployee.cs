﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using Bunifu.Framework.UI;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nTech.business_logic_layer.admin;

namespace nTech.presentation_layer.admin_presentation
{
    public partial class addEmployee : Form
    {
        public addEmployee()
        {
            InitializeComponent();
        }

       

        
        private void addEmployee_Load(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            EmployeeLogic a = new EmployeeLogic();
            Dictionary<String, String> emp = new Dictionary<String, String>();
            emp.Add("name", Ename.Text);
            emp.Add("age", Eage.Text);
            emp.Add("phone", Ephone.Text);
            emp.Add("address", Eaddress.Text);
            emp.Add("salary", Esalary.Text);
            emp.Add("id", Eid.Text);
            emp.Add("gender", Egender.Text);
            emp.Add("pass", Epass.Text);
            string l = a.addemp(emp);


           


        }

        

        private void E_click(object sender, EventArgs e)
        {

            BunifuMaterialTextbox text = (BunifuMaterialTextbox)sender;
            if (text.Text == "Name")
            {
                text.Text = " ";
            }
            else if (text.Text == "Age")
            {
                text.Text = "";
            }
            else if (text.Text == "Phone")
            {
                text.Text = "";
            }
            else if (text.Text == "Address")
            {
                text.Text = "";
            }
            else if (text.Text == "Salary")
            {
                text.Text = "";
            }
            else if (text.Text == "Id Number")
            {
                text.Text = "";
            }
            else if (text.Text == "Password")
            {
                text.Text = "";
                
            }
           
        }
    }
}
