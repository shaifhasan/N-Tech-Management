﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using nTech.presentation_layer.admin_presentation;


namespace nTech
{
    public partial class home : Form
    {
       
        public home()
        {
            InitializeComponent();
        }

       
           
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            pictureBox2.Visible = false;
            pictureBox4.Visible = true;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            pictureBox2.Visible = true;
            pictureBox4.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
           
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            
            pictureBox1.BackColor = Color.Red;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.White;
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            pictureBox4.BackColor = Color.Red;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            pictureBox3.BackColor = Color.Red;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.BackColor = Color.Red;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.BackColor = Color.WhiteSmoke;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

            dashBoard f1 = new dashBoard();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();
           
            
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (menuShadow.Width == 194)
            {
                menuShadow.Width = 58;
                menuBar.Width = 58;
            }
            else
            {
                menuShadow.Width = 194;
                menuBar.Width = 194;
            }
        }

        private void panel1_MouseDown_1(object sender, MouseEventArgs e)
        {
               
        
          
        
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
                if(this.panel2.Controls.Count>0)
                this.panel2.Controls.RemoveAt(0);

                addEmployee f1 = new addEmployee();
                f1.TopLevel = false;
                f1.Dock = DockStyle.Fill;
                this.panel2.Controls.Add(f1);
                f1.Show();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
                if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

                addProducts f1 = new addProducts();
                f1.TopLevel = false;
                f1.Dock = DockStyle.Fill;
                this.panel2.Controls.Add(f1);
                f1.Show();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

            employeeList f1 = new employeeList();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

            productList f1 = new productList();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();

        }

        private void menu_Click(object sender, EventArgs e)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

            dashBoard f1 = new dashBoard();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

            settings f1 = new settings();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();


        }

        private void production_list(object sender, EventArgs e)
        {

            if (this.panel2.Controls.Count > 0)
                this.panel2.Controls.RemoveAt(0);

           production f1 = new production();
            f1.TopLevel = false;
            f1.Dock = DockStyle.Fill;
            this.panel2.Controls.Add(f1);
            f1.Show();
        }
    }
}
