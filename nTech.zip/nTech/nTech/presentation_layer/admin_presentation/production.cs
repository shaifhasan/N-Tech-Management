﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nTech.business_logic_layer.admin;

namespace nTech.presentation_layer.admin_presentation
{
    public partial class production : Form
    {
        public production()
        {
            InitializeComponent();
        }

        private void production_Load(object sender, EventArgs e)
        {
            ProductionLogic pro = new ProductionLogic();
            DataTable proList = pro.getProduction();
            productionList.DataSource = proList;
        }
    }
}
