﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using Bunifu.Framework.UI;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nTech.business_logic_layer.admin;

namespace nTech.presentation_layer.admin_presentation
{
    public partial class addProducts : Form
    {
        public addProducts()
        {
            InitializeComponent();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            ProductLogic p = new ProductLogic();

            Dictionary<String, String> pro = new Dictionary<String, String>();
            pro.Add("name", Pname.Text);
            pro.Add("num", Pnum.Text);
            pro.Add("price", Pprice.Text);
            pro.Add("quantity", Pquan.Text);
           
            string l = p.addProduct(pro);

            label1.Text = l;
          
        }

        private void E_Click(object sender, EventArgs e)
        {
            BunifuMaterialTextbox text = (BunifuMaterialTextbox)sender;
            if (text.Text == "Product Name")
            {
                text.Text = " ";
            }
            else if (text.Text == "Product Number")
            {
                text.Text = "";
            }
            else if (text.Text == "Product Price")
            {
                text.Text = "";
            }
            else if (text.Text == "Quantity")
            {
                text.Text = "";
            }
            

        }
    }
}
