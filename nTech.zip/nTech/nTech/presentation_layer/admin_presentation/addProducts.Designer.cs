﻿namespace nTech.presentation_layer.admin_presentation
{
    partial class addProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addProducts));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.Pname = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Pnum = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Pquan = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Pprice = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Pname
            // 
            this.Pname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Pname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Pname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Pname.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Pname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pname.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Pname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Pname.HintForeColor = System.Drawing.Color.Empty;
            this.Pname.HintText = "";
            this.Pname.isPassword = false;
            this.Pname.LineFocusedColor = System.Drawing.Color.Blue;
            this.Pname.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Pname.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Pname.LineThickness = 3;
            this.Pname.Location = new System.Drawing.Point(13, 95);
            this.Pname.Margin = new System.Windows.Forms.Padding(4);
            this.Pname.MaxLength = 32767;
            this.Pname.Name = "Pname";
            this.Pname.Size = new System.Drawing.Size(379, 33);
            this.Pname.TabIndex = 0;
            this.Pname.Text = "Product Name";
            this.Pname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Pname.Click += new System.EventHandler(this.E_Click);
            // 
            // Pnum
            // 
            this.Pnum.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Pnum.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Pnum.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Pnum.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Pnum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pnum.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Pnum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Pnum.HintForeColor = System.Drawing.Color.Empty;
            this.Pnum.HintText = "";
            this.Pnum.isPassword = false;
            this.Pnum.LineFocusedColor = System.Drawing.Color.Blue;
            this.Pnum.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Pnum.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Pnum.LineThickness = 3;
            this.Pnum.Location = new System.Drawing.Point(13, 150);
            this.Pnum.Margin = new System.Windows.Forms.Padding(4);
            this.Pnum.MaxLength = 32767;
            this.Pnum.Name = "Pnum";
            this.Pnum.Size = new System.Drawing.Size(379, 33);
            this.Pnum.TabIndex = 0;
            this.Pnum.Text = "Product Number";
            this.Pnum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Pnum.Click += new System.EventHandler(this.E_Click);
            // 
            // Pquan
            // 
            this.Pquan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Pquan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Pquan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Pquan.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Pquan.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pquan.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Pquan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Pquan.HintForeColor = System.Drawing.Color.Empty;
            this.Pquan.HintText = "";
            this.Pquan.isPassword = false;
            this.Pquan.LineFocusedColor = System.Drawing.Color.Blue;
            this.Pquan.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Pquan.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Pquan.LineThickness = 3;
            this.Pquan.Location = new System.Drawing.Point(13, 260);
            this.Pquan.Margin = new System.Windows.Forms.Padding(4);
            this.Pquan.MaxLength = 32767;
            this.Pquan.Name = "Pquan";
            this.Pquan.Size = new System.Drawing.Size(379, 33);
            this.Pquan.TabIndex = 0;
            this.Pquan.Text = "Quantity";
            this.Pquan.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Pquan.Click += new System.EventHandler(this.E_Click);
            // 
            // Pprice
            // 
            this.Pprice.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Pprice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.Pprice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.Pprice.characterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.Pprice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Pprice.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.Pprice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Pprice.HintForeColor = System.Drawing.Color.Empty;
            this.Pprice.HintText = "";
            this.Pprice.isPassword = false;
            this.Pprice.LineFocusedColor = System.Drawing.Color.Blue;
            this.Pprice.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Pprice.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Pprice.LineThickness = 3;
            this.Pprice.Location = new System.Drawing.Point(13, 205);
            this.Pprice.Margin = new System.Windows.Forms.Padding(4);
            this.Pprice.MaxLength = 32767;
            this.Pprice.Name = "Pprice";
            this.Pprice.Size = new System.Drawing.Size(379, 33);
            this.Pprice.TabIndex = 0;
            this.Pprice.Text = "Product Price";
            this.Pprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Pprice.Click += new System.EventHandler(this.E_Click);
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.ButtonText = "Add";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.Gray;
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.White;
            this.bunifuButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton1.IdleBorderRadius = 1;
            this.bunifuButton1.IdleBorderThickness = 0;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.Location = new System.Drawing.Point(182, 332);
            this.bunifuButton1.Name = "bunifuButton1";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.BorderRadius = 1;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.bunifuButton1.onHoverState = stateProperties1;
            this.bunifuButton1.Size = new System.Drawing.Size(210, 45);
            this.bunifuButton1.TabIndex = 1;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(426, 136);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 144);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(438, 293);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "Products";
            // 
            // addProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 447);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bunifuButton1);
            this.Controls.Add(this.Pquan);
            this.Controls.Add(this.Pprice);
            this.Controls.Add(this.Pnum);
            this.Controls.Add(this.Pname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "addProducts";
            this.Text = "addProducts";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuMaterialTextbox Pname;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Pnum;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Pquan;
        private Bunifu.Framework.UI.BunifuMaterialTextbox Pprice;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}