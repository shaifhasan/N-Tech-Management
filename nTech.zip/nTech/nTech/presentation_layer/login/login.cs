﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bunifu.Framework.UI;
using System.Runtime.InteropServices;
using nTech.presentation_layer.employee_presentation;
using nTech.business_logic_layer.login_logic;




namespace nTech
{
    public partial class login : Form
    {
        loginControl log = new loginControl();
       
        public login()
        {
            InitializeComponent();
        }

       

           
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            pictureBox2.Visible = false;
            pictureBox4.Visible = true;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            pictureBox2.Visible = true;
            pictureBox4.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
           
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            
            pictureBox1.BackColor = Color.Red;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.CornflowerBlue;
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            pictureBox4.BackColor = Color.Red;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.BackColor = Color.CornflowerBlue;
        }

        private void pictureBox3_MouseHover(object sender, EventArgs e)
        {
            pictureBox3.BackColor = Color.Red;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.BackColor = Color.CornflowerBlue;
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.BackColor = Color.Red;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.BackColor = Color.CornflowerBlue;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            if (passText.Text != null && userText.Text != null)
            {
                if (passText.Text != "Password" && userText.Text != "User Name")
                {
                    string status = " ";
                    status = log.loginVerify(userText.Text, passText.Text);
                    status = status.Trim();

                    if (status.Equals("admin"))
                    {
                        home h1 = new home();
                        this.Hide();
                        h1.Show();
                    }
                    else if (status.Equals("employee"))
                    {
                        employeeHome e1 = new employeeHome();
                        this.Hide();
                        e1.Show();
                    }
                    else
                        MessageBox.Show("invalid username or password");
                }
                else
                    MessageBox.Show("enter username or password");
                
            }
            else
                MessageBox.Show("enter username or password");


           

        }

        private void userText_MouseClick(object sender, EventArgs e)
        {
            BunifuMaterialTextbox text = (BunifuMaterialTextbox)sender;
            if (text.Text == "User Name")
            {
                text.Text = " ";
            }
            else if (text.Text == "Password")
            {
                text.Text = "";
            }
        }

       

        

     

        
    }
}
