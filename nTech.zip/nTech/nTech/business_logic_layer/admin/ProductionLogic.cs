﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using nTech.data_access_layer.admin_data;

namespace nTech.business_logic_layer.admin
{
    class ProductionLogic
    {
        ProductionData p = new ProductionData();

        public DataTable getProduction()
        {

            return p.getProduction();

        }
    }
}
