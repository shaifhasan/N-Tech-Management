﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using nTech.data_access_layer.login_data;

namespace nTech.business_logic_layer.login_logic
{
    class loginControl
    {
        loginData log = new loginData();

        public string loginVerify(string name, string password)
        {
            return log.loginVerify(name,password);
        }
    }
}
