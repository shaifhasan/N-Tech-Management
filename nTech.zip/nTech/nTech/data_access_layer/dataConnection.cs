﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace nTech.data_access_layer
{
    class dataConnection
    {
        private SqlConnection con = null;
        public dataConnection()
        {
            //int rowCount;
            con = new SqlConnection(@"Data Source=DESKTOP-DKVKFL2\SQLEXPRESS;Initial Catalog=nTech;Integrated Security=True;");
        }

        public SqlConnection getCon
        {
            get { return con; }
        }
    }
}
