﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using nTech.data_access_layer;

namespace nTech.data_access_layer.login_data
{
    class loginData
    {
        dataConnection con = new dataConnection();
        public string loginVerify(string name, string password)
        {
            int rowCount;
            
            
            var conn = con.getCon;
            conn.Open();
            SqlCommand quary = new SqlCommand();
            quary.Connection =conn;
            quary.CommandText = "select * from loginInfo where idNumber=@idNumber and password=@pass";
            quary.Parameters.Add(new SqlParameter("@idNumber", name));
            quary.Parameters.Add(new SqlParameter("@pass", password));
            SqlDataAdapter data = new SqlDataAdapter(quary);
            DataTable dt = new DataTable();
            rowCount = data.Fill(dt);
            conn.Close();
            if (rowCount == 0)
            {
                return "invalid";
            }
            else
            {
                string m = dt.Rows[0]["type"].ToString();
                m.Trim();
                string r = m;
                return r;
            }
        }
    }
}
