﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using nTech.data_access_layer;

namespace nTech.data_access_layer.admin_data
{
    class EmployeeData
    {
        dataConnection con = new dataConnection();
        public string addEmp(Dictionary<string,string> emp)
        {


            string m;
            int id;
            var conn = con.getCon;
            
            conn.Open();
            SqlCommand quary = new SqlCommand();
            quary.Connection = conn;
            quary.CommandText = "insert into employee (name, age, phone,gender,address,salary,idNumber,post,createDate) output INSERTED.userId  values (@name,@age, @phone,@gender,@address,@salary,@idNum,@post,@date)";
            
            quary.Parameters.Add(new SqlParameter("@name", emp["name"]));
            quary.Parameters.Add(new SqlParameter("@age", emp["age"]));
            quary.Parameters.Add(new SqlParameter("@phone", emp["phone"]));
            quary.Parameters.Add(new SqlParameter("@gender", emp["gender"]));
            quary.Parameters.Add(new SqlParameter("@address", emp["address"]));
            quary.Parameters.Add(new SqlParameter("@salary", emp["salary"]));
            quary.Parameters.Add(new SqlParameter("@idNum", emp["id"]));
            quary.Parameters.Add(new SqlParameter("@post", "employee"));
            quary.Parameters.Add(new SqlParameter("@date", DateTime.Today));
           
            id=(Int32)quary.ExecuteScalar();

            conn.Close();
          
            m = addLogin(emp, id);
           
            
            return m;
        }

        public string addLogin(Dictionary<string,string> log,int id)
        {
            var conn = con.getCon;
            int r;
           
            conn.Open();
            SqlCommand quary = new SqlCommand();
            quary.Connection = conn;
            quary.CommandText = "insert into loginInfo (id, idNumber,password ,status,type) values (@id,@idNum, @pass,@status,@type)";
           
            quary.Parameters.Add(new SqlParameter("@id",id));
            quary.Parameters.Add(new SqlParameter("@idNum", log["id"]));
            quary.Parameters.Add(new SqlParameter("@pass", log["pass"]));
            quary.Parameters.Add(new SqlParameter("@status","active"));
            quary.Parameters.Add(new SqlParameter("@type","employee"));
           
             
            r=quary.ExecuteNonQuery();
            conn.Close();
            if (r == 1)
            {
                return "success";
            }
            else
                return "invalid";
           
        }


        public DataTable getEmpList()
        {
            var conn = con.getCon;
            DataTable data = new DataTable();
            SqlCommand quary = new SqlCommand();
            
            quary.Connection = conn;
            quary.CommandText = "select name as NAME,age AS AGE,phone AS PHONE,gender AS GENDER,address AS ADDRESS,salary AS SALARY,idNumber AS ID,post AS POST,createDate AS 'HIRE DATE' from employee";
            SqlDataAdapter da = new SqlDataAdapter(quary);
            da.Fill(data);
            return data;
 
        
        }



        
            


    }
}
