﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Threading.Tasks;
using nTech.data_access_layer;

namespace nTech.data_access_layer.admin_data
{
    class ProductData
    {
        dataConnection con = new dataConnection();
        public string addProduct(Dictionary<string, string> pro)
        {


            string m;
            var conn = con.getCon;

            conn.Open();
            SqlCommand quary = new SqlCommand();
            quary.Connection = conn;
            quary.CommandText = "insert into product (productName, productNumber,productType,productPrice,productQuantity,createDate) values (@name,@idNum,@type,@price,@quantity,@date)";

            quary.Parameters.Add(new SqlParameter("@name", pro["name"]));
            quary.Parameters.Add(new SqlParameter("@idNum", pro["num"]));
            quary.Parameters.Add(new SqlParameter("@type","Metarial"));
            quary.Parameters.Add(new SqlParameter("@price", pro["price"]));
            quary.Parameters.Add(new SqlParameter("@quantity", pro["quantity"]));
            quary.Parameters.Add(new SqlParameter("@date", DateTime.Today));

            m=quary.ExecuteNonQuery().ToString();

            conn.Close();

           

            return m;
        }

        public DataSet getProList()
        {
            var conn = con.getCon;
            DataSet data = new DataSet();
            SqlCommand quary = new SqlCommand();

            quary.Connection = conn;
            quary.CommandText = "select productName AS NAME,productNumber AS NUMBER,productType AS TYPE,productPrice AS PRICE,productQuantity AS QUANTITY,createDate AS CREATED from product";
            SqlDataAdapter da = new SqlDataAdapter(quary);
            da.Fill(data);
            return data;


        }

    }
}
