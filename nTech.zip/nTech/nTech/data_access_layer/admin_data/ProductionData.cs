﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace nTech.data_access_layer.admin_data
{
    class ProductionData
    {
        dataConnection con = new dataConnection();

        public DataTable getProduction()
        {
            var conn = con.getCon;
            
            SqlCommand quary = new SqlCommand();

            quary.Connection = conn;
            quary.CommandText = "select productName AS NAME,productNumber AS NUMBER,employeeId AS EMPLOYEE,Quantity AS QUANTITY,productionDate AS CREATED_AT from product,production where product.productId=production.productId ";
            DataTable data = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(quary);
            da.Fill(data);
            return data;


        }
    }
}
